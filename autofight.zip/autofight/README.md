# AutoFight – Epic Fight Auto Parry / Auto Dodge (Client-side)

Forge 1.20.1 (47.x) · Epic Fight 20.x · ลงเฉพาะเครื่องเราคนเดียว (เซิร์ฟเวอร์ไม่ต้องลง)

## วิธี build
1. ติดตั้ง JDK 17
2. ในโฟลเดอร์นี้ รัน (ต้องมี Gradle 8.x ติดตั้ง หรือคัดลอก gradle wrapper จาก Forge MDK 1.20.1 มาใส่):
   - `gradle build`
3. ได้ไฟล์ `build/libs/autofight-1.0.0.jar` → ใส่ในโฟลเดอร์ `mods` ของ client

## วิธีใช้
- กด **Right Shift** เปิดเมนู (เปลี่ยนปุ่มได้ใน Controls → AutoFight)
- **Auto Parry** – กดปุ่ม Guard ของ Epic Fight ให้อัตโนมัติ เมื่อศัตรูอยู่ในระยะ **Parry Range**
- **Auto Dodge** – กดปุ่ม Dodge ของ Epic Fight + ทิศทางการเคลื่อนที่ให้อัตโนมัติ ในระยะ **Dodge Range**
- **Guard Hold / Cooldown** – ระยะเวลายกการ์ด / เวลาพักระหว่างการกระทำ (หน่วย tick, 20 tick = 1 วินาที)
- **Detection** – Smart (จับท่าฟัน/การพุ่งเข้าหา) หรือ Proximity (ศัตรูอยู่ในระยะและหันหน้ามาหาก็ทำงาน)
- ค่าถูกเก็บที่ `config/autofight.properties`

## หมายเหตุ
- ม็อดนี้ไม่ได้ผูกกับโค้ดของ Epic Fight โดยตรง แต่ "กดปุ่มของผู้เล่นเอง" (Guard/Dodge/WASD) จึงไม่ต้องลงฝั่งเซิร์ฟเวอร์
- ถ้า Epic Fight เวอร์ชันของคุณใช้ชื่อปุ่มต่างไป ม็อดจะหาปุ่มที่ชื่อมี `epicfight` + `dodge`/`guard` ให้เอง และถ้าไม่เจอปุ่ม guard จะใช้ปุ่มคลิกขวา
- เซิร์ฟเวอร์หลายแห่งห้ามใช้ม็อดช่วยต่อสู้ ตรวจกฎก่อนใช้ออนไลน์
