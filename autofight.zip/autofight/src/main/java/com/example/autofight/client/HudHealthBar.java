package com.example.autofight.client;

import com.example.autofight.AFConfig;
import com.example.autofight.AutoFightMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Flat on-screen health bar (HUD): red bar, dark border, "204/204" text in the middle.
 * Client-side only.
 */
public class HudHealthBar {

    private static float trail = -1f;
    private static long lastNanos = 0L;

    // ------------------------------------------------------------ registration (mod bus)

    @Mod.EventBusSubscriber(modid = AutoFightMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class Register {
        @SubscribeEvent
        public static void onRegister(RegisterGuiOverlaysEvent e) {
            e.registerAboveAll("health_bar", HudHealthBar::render);
        }
    }

    // ------------------------------------------------- hide vanilla hearts (forge bus)

    @Mod.EventBusSubscriber(modid = AutoFightMod.MODID, value = Dist.CLIENT)
    public static class HideVanilla {
        @SubscribeEvent
        public static void onOverlay(RenderGuiOverlayEvent.Pre e) {
            if (AFConfig.healthBar && AFConfig.hbHideVanilla
                    && e.getOverlay().id().equals(VanillaGuiOverlay.PLAYER_HEALTH.id())) {
                e.setCanceled(true);
            }
        }
    }

    // ------------------------------------------------------------------- drawing

    private static void render(ForgeGui gui, GuiGraphics g, float partialTick, int screenW, int screenH) {
        if (!AFConfig.healthBar) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || p.isSpectator()) return;

        float max = Math.max(1.0f, p.getMaxHealth());
        float cur = Mth.clamp(p.getHealth(), 0.0f, max);
        float abs = p.getAbsorptionAmount();

        // smooth "recent damage" trail
        long now = System.nanoTime();
        float dt = lastNanos == 0L ? 0.0f : Math.min(0.25f, (now - lastNanos) / 1.0E9f);
        lastNanos = now;
        if (trail < 0f || trail < cur) trail = cur;
        else trail += (cur - trail) * Math.min(1.0f, dt * 2.5f);

        if (AFConfig.hbHideFull && cur >= max - 0.01f && abs <= 0.0f && trail <= cur + 0.01f) return;

        int w = AFConfig.hbWidth;
        int h = AFConfig.hbHeight;
        int x0 = (screenW - w) / 2 + AFConfig.hbX;
        int y1 = screenH - AFConfig.hbY;
        int y0 = y1 - h;
        int x1 = x0 + w;

        // border (dark outer, lighter inner line, like the reference bar)
        g.fill(x0 - 2, y0 - 2, x1 + 2, y1 + 2, 0xFF141414);
        g.fill(x0 - 1, y0 - 1, x1 + 1, y1 + 1, 0xFF5A5A5A);
        // background
        g.fill(x0, y0, x1, y1, 0xFF3B0000);

        float frac = cur / max;
        float trailFrac = Mth.clamp(trail / max, 0.0f, 1.0f);

        // recent damage (white-ish)
        if (trailFrac > frac) {
            g.fill(x0 + Math.round(w * frac), y0, x0 + Math.round(w * trailFrac), y1, 0xFFE8E8E8);
        }
        // current health (red)
        int fw = Math.round(w * frac);
        if (fw > 0) {
            g.fill(x0, y0, x0 + fw, y1, 0xFFFF0000);
            g.fill(x0, y0, x0 + fw, y0 + Math.max(1, h / 6), 0x33FFFFFF);
        }
        // absorption (gold strip under the bar)
        if (abs > 0.0f) {
            int aw = Math.round(w * Mth.clamp(abs / max, 0.0f, 1.0f));
            g.fill(x0, y1 + 2, x0 + aw, y1 + 4, 0xFFFFC21A);
        }

        if (AFConfig.hbText) {
            String txt = Math.round(cur) + "/" + Math.round(max);
            if (abs > 0.0f) txt += " +" + Math.round(abs);
            int ty = y0 + (h - 8) / 2 + 1;
            g.drawCenteredString(mc.font, txt, x0 + w / 2, ty, 0xFFFFFFFF);
        }
    }
}
