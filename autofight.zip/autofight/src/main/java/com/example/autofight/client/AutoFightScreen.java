package com.example.autofight.client;

import com.example.autofight.AFConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

/** Settings menu styled like a dark "hub" panel: toggles, sliders with value box, dropdown-style cyclers. */
public class AutoFightScreen extends Screen {

    // palette
    private static final int C_DIM = 0x99000000;
    private static final int C_PANEL = 0xF0383117;
    private static final int C_BORDER = 0xFF0C0A04;
    private static final int C_ROW = 0xFF433B1C;
    private static final int C_BOX = 0xFF17130A;
    private static final int C_GREEN = 0xFF1FA21A;
    private static final int C_GREEN_HI = 0xFF55F040;
    private static final int C_WHITE = 0xFFFFFFFF;
    private static final int C_SUB = 0xFFB9B39A;

    private static final String[] DETECT = {"Smart", "Proximity"};
    private static final String[] TARGETS = {"Hostile", "All Mobs", "Mobs + Players"};
    private static final String[] DIRS = {"Backward", "Sideways", "Away"};

    private final List<Row> rows = new ArrayList<>();
    private int scroll = 0;
    private int panelX, panelY, panelW, panelH, listTop, listH;
    private Row dragging = null;

    private static final int ROW_H = 44;
    private static final int GAP = 4;

    public AutoFightScreen() {
        super(Component.literal("AutoFight"));

        rows.add(new Toggle("Auto Parry", "Raises your guard right before a hit lands",
                () -> AFConfig.autoParry, v -> AFConfig.autoParry = v));
        rows.add(new Toggle("Auto Dodge", "Presses the Epic Fight dodge key for you",
                () -> AFConfig.autoDodge, v -> AFConfig.autoDodge = v));
        rows.add(new Slider("Parry Range", "Block distance that triggers a parry",
                1, 8, 0.5, () -> AFConfig.parryRange, v -> AFConfig.parryRange = (float) v, false));
        rows.add(new Slider("Dodge Range", "Block distance that triggers a dodge",
                1, 8, 0.5, () -> AFConfig.dodgeRange, v -> AFConfig.dodgeRange = (float) v, false));
        rows.add(new Slider("Enemy Reach", "How far enemies can hit you (blocks)",
                1, 6, 0.5, () -> AFConfig.enemyReach, v -> AFConfig.enemyReach = (float) v, false));
        rows.add(new Slider("Parry Timing", "Guard up this many ticks before the hit",
                0, 10, 1, () -> AFConfig.parryLead, v -> AFConfig.parryLead = (int) v, true));
        rows.add(new Slider("Dodge Timing", "Dodge this many ticks before the hit",
                0, 10, 1, () -> AFConfig.dodgeLead, v -> AFConfig.dodgeLead = (int) v, true));
        rows.add(new Slider("Guard Hold", "Ticks to keep guard up (20 = 1 sec)",
                2, 30, 1, () -> AFConfig.guardHold, v -> AFConfig.guardHold = (int) v, true));
        rows.add(new Slider("Cooldown", "Ticks between two automatic actions",
                0, 40, 1, () -> AFConfig.cooldown, v -> AFConfig.cooldown = (int) v, true));
        rows.add(new Cycle("Detection", "Smart = swing / rush, Proximity = any enemy in range",
                DETECT, () -> AFConfig.detectMode, v -> AFConfig.detectMode = v));
        rows.add(new Cycle("Targets", "Which entities count as a threat",
                TARGETS, () -> AFConfig.targetMode, v -> AFConfig.targetMode = v));
        rows.add(new Cycle("Dodge Direction", "Away = roll away from the attacker",
                DIRS, () -> AFConfig.dodgeDir, v -> AFConfig.dodgeDir = v));
        rows.add(new Toggle("Dodge Projectiles", "Also dodge arrows and fireballs",
                () -> AFConfig.dodgeProjectiles, v -> AFConfig.dodgeProjectiles = v));
        rows.add(new Toggle("Debug Info", "Shows what was detected on the action bar",
                () -> AFConfig.debug, v -> AFConfig.debug = v));
    }

    @Override
    protected void init() {
        panelW = Math.min(this.width - 12, 400);
        panelH = Math.min(this.height - 12, 250);
        panelX = (this.width - panelW) / 2;
        panelY = (this.height - panelH) / 2;
        listTop = panelY + 28;
        listH = panelH - 28 - 6;
        clampScroll();
    }

    private int contentH() {
        return rows.size() * (ROW_H + GAP);
    }

    private void clampScroll() {
        int max = Math.max(0, contentH() - listH);
        scroll = Math.max(0, Math.min(max, scroll));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void onClose() {
        AFConfig.save();
        super.onClose();
    }

    // ---------------------------------------------------------------- render

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, this.width, this.height, C_DIM);

        g.fill(panelX - 2, panelY - 2, panelX + panelW + 2, panelY + panelH + 2, C_BORDER);
        g.fill(panelX, panelY, panelX + panelW, panelY + panelH, C_PANEL);

        g.drawString(this.font, Component.literal("AutoFight").withStyle(ChatFormatting.BOLD), panelX + 8, panelY + 9, C_WHITE, true);
        g.drawString(this.font, "Epic Fight  -  client only", panelX + 8 + 70, panelY + 9, C_SUB, false);
        String hint = "Esc = save & close";
        g.drawString(this.font, hint, panelX + panelW - this.font.width(hint) - 8, panelY + 9, C_SUB, false);

        g.enableScissor(panelX, listTop, panelX + panelW, listTop + listH);
        int y = listTop - scroll;
        for (Row r : rows) {
            if (y + ROW_H >= listTop && y <= listTop + listH) {
                r.render(g, panelX + 6, y, panelW - 12, ROW_H, mx, my);
            }
            y += ROW_H + GAP;
        }
        g.disableScissor();

        // scrollbar
        int max = contentH() - listH;
        if (max > 0) {
            int trackX = panelX + panelW - 4;
            int barH = Math.max(16, listH * listH / contentH());
            int barY = listTop + (int) ((long) (listH - barH) * scroll / max);
            g.fill(trackX, listTop, trackX + 2, listTop + listH, 0x55000000);
            g.fill(trackX, barY, trackX + 2, barY + barH, C_GREEN_HI);
        }
    }

    // ----------------------------------------------------------------- input

    private Row rowAt(double mx, double my, int[] outY) {
        if (my < listTop || my > listTop + listH) return null;
        int y = listTop - scroll;
        for (Row r : rows) {
            if (my >= y && my < y + ROW_H) {
                outY[0] = y;
                return r;
            }
            y += ROW_H + GAP;
        }
        return null;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        int[] ry = new int[1];
        Row r = rowAt(mx, my, ry);
        if (r != null && mx >= panelX + 6 && mx <= panelX + panelW - 6) {
            if (r.click(mx, my, panelX + 6, ry[0], panelW - 12, ROW_H, button)) {
                dragging = r.draggable() ? r : null;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging != null) {
            dragging.drag(mx, panelX + 6, panelW - 12);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (dragging != null) {
            dragging = null;
            AFConfig.save();
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        scroll -= (int) (delta * 20);
        clampScroll();
        return true;
    }

    // ------------------------------------------------------------------ rows

    private abstract class Row {
        final String title;
        final String sub;

        Row(String title, String sub) {
            this.title = title;
            this.sub = sub;
        }

        void render(GuiGraphics g, int x, int y, int w, int h, int mx, int my) {
            g.fill(x, y, x + w, y + h, C_BORDER);
            g.fill(x + 1, y + 1, x + w - 1, y + h - 1, C_ROW);
            g.drawString(font, Component.literal(title).withStyle(ChatFormatting.BOLD), x + 8, y + 9, C_WHITE, true);
            int maxSub = w - controlW() - 20;
            String s = font.plainSubstrByWidth(sub, maxSub);
            g.drawString(font, s, x + 8, y + 24, C_SUB, false);
            control(g, x + w - controlW() - 8, y, controlW(), h);
        }

        int controlW() {
            return 56;
        }

        abstract void control(GuiGraphics g, int x, int y, int w, int h);

        boolean click(double mx, double my, int x, int y, int w, int h, int button) {
            return false;
        }

        boolean draggable() {
            return false;
        }

        void drag(double mx, int x, int w) {
        }
    }

    private class Toggle extends Row {
        private final BooleanSupplier get;
        private final Consumer<Boolean> set;

        Toggle(String t, String s, BooleanSupplier get, Consumer<Boolean> set) {
            super(t, s);
            this.get = get;
            this.set = set;
        }

        @Override
        void control(GuiGraphics g, int x, int y, int w, int h) {
            boolean on = get.getAsBoolean();
            int bx = x + w - 52, by = y + (h - 24) / 2;
            g.fill(bx - 1, by - 1, bx + 53, by + 25, C_BORDER);
            g.fill(bx, by, bx + 52, by + 24, on ? C_GREEN : C_BOX);
            if (on) g.fill(bx, by, bx + 52, by + 2, C_GREEN_HI);
            int kx = on ? bx + 52 - 24 : bx + 2;
            g.fill(kx, by + 2, kx + 22, by + 22, C_BORDER);
            g.fill(kx + 1, by + 3, kx + 21, by + 21, C_WHITE);
        }

        @Override
        boolean click(double mx, double my, int x, int y, int w, int h, int button) {
            set.accept(!get.getAsBoolean());
            AFConfig.save();
            return true;
        }
    }

    private class Slider extends Row {
        private final double min, max, step;
        private final DoubleSupplier get;
        private final java.util.function.DoubleConsumer set;
        private final boolean integer;
        private int trackX, trackW;

        Slider(String t, String s, double min, double max, double step,
               DoubleSupplier get, java.util.function.DoubleConsumer set, boolean integer) {
            super(t, s);
            this.min = min;
            this.max = max;
            this.step = step;
            this.get = get;
            this.set = set;
            this.integer = integer;
        }

        @Override
        int controlW() {
            return 150;
        }

        @Override
        void control(GuiGraphics g, int x, int y, int w, int h) {
            // value box
            int boxW = 34, bh = 22, by = y + (h - bh) / 2;
            g.fill(x - 1, by - 1, x + boxW + 1, by + bh + 1, C_BORDER);
            g.fill(x, by, x + boxW, by + bh, C_BOX);
            double v = get.getAsDouble();
            String txt = integer ? String.valueOf((int) v) : String.format("%.1f", v);
            g.drawString(font, Component.literal(txt).withStyle(ChatFormatting.BOLD),
                    x + (boxW - font.width(txt)) / 2, by + 7, C_WHITE, true);

            // track
            trackX = x + boxW + 8;
            trackW = w - boxW - 8 - 2;
            int ty = y + h / 2 - 5;
            g.fill(trackX - 1, ty - 1, trackX + trackW + 1, ty + 11, C_BORDER);
            g.fill(trackX, ty, trackX + trackW, ty + 10, C_BOX);
            double frac = (v - min) / (max - min);
            int knobW = 12;
            int fillW = (int) (frac * (trackW - knobW)) + knobW;
            g.fill(trackX, ty, trackX + fillW, ty + 10, C_GREEN);
            g.fill(trackX, ty, trackX + fillW, ty + 2, C_GREEN_HI);
            int kx = trackX + (int) (frac * (trackW - knobW));
            g.fill(kx, ty - 3, kx + knobW, ty + 13, C_BORDER);
            g.fill(kx + 1, ty - 2, kx + knobW - 1, ty + 12, C_WHITE);
        }

        @Override
        boolean click(double mx, double my, int x, int y, int w, int h, int button) {
            if (mx < x + w - controlW() - 8) return false;
            drag(mx, x, w);
            return true;
        }

        @Override
        boolean draggable() {
            return true;
        }

        @Override
        void drag(double mx, int x, int w) {
            int knobW = 12;
            double frac = (mx - trackX - knobW / 2.0) / (trackW - knobW);
            frac = Math.max(0, Math.min(1, frac));
            double v = min + frac * (max - min);
            v = Math.round(v / step) * step;
            v = Math.max(min, Math.min(max, v));
            set.accept(v);
        }
    }

    private class Cycle extends Row {
        private final String[] options;
        private final IntSupplier get;
        private final IntConsumer set;

        Cycle(String t, String s, String[] options, IntSupplier get, IntConsumer set) {
            super(t, s);
            this.options = options;
            this.get = get;
            this.set = set;
        }

        @Override
        int controlW() {
            return 118;
        }

        @Override
        void control(GuiGraphics g, int x, int y, int w, int h) {
            int bh = 24, by = y + (h - bh) / 2;
            g.fill(x - 1, by - 1, x + w + 1, by + bh + 1, C_BORDER);
            g.fill(x, by, x + w, by + bh, C_BOX);
            String txt = options[get.getAsInt()];
            g.drawString(font, Component.literal(txt).withStyle(ChatFormatting.BOLD), x + 8, by + 8, C_WHITE, true);
            g.drawString(font, "v", x + w - 14, by + 8, C_GREEN_HI, true);
        }

        @Override
        boolean click(double mx, double my, int x, int y, int w, int h, int button) {
            int n = options.length;
            int cur = get.getAsInt();
            set.accept(button == 1 ? (cur + n - 1) % n : (cur + 1) % n);
            AFConfig.save();
            return true;
        }
    }
}
