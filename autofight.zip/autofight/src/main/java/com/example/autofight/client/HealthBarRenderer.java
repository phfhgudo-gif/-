package com.example.autofight.client;

import com.example.autofight.AFConfig;
import com.example.autofight.AutoFightMod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/**
 * Draws a floating health bar above the local player's head (visible in third person / when
 * other cameras look at you). Client-side only. It is drawn in the level render stage instead
 * of the entity renderer, so it also works while Epic Fight replaces the player's renderer.
 */
@Mod.EventBusSubscriber(modid = AutoFightMod.MODID, value = Dist.CLIENT)
public class HealthBarRenderer {

    /** Delayed "recent damage" bar, drains smoothly towards the real health. */
    private static float trail = -1f;
    private static long lastNanos = 0L;

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_ENTITIES) return;
        if (!AFConfig.healthBar) return;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || !p.isAlive() || p.isSpectator()) return;
        if (mc.options.hideGui) return;
        if (mc.options.getCameraType().isFirstPerson()) return; // you cannot see above your own head

        float max = Math.max(1.0f, p.getMaxHealth());
        float cur = Mth.clamp(p.getHealth(), 0.0f, max);
        float abs = p.getAbsorptionAmount();

        // ---- trail animation
        long now = System.nanoTime();
        float dt = lastNanos == 0L ? 0.0f : Math.min(0.25f, (now - lastNanos) / 1.0E9f);
        lastNanos = now;
        if (trail < 0f || trail < cur) trail = cur;
        else trail += (cur - trail) * Math.min(1.0f, dt * 2.5f);

        if (AFConfig.hbHideFull && cur >= max - 0.01f && abs <= 0.0f && trail <= cur + 0.01f) return;

        float pt = e.getPartialTick();
        Camera cam = e.getCamera();
        Vec3 pos = p.getPosition(pt);
        Vec3 cp = cam.getPosition();

        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.translate(pos.x - cp.x, pos.y - cp.y + p.getBbHeight() + AFConfig.hbOffset, pos.z - cp.z);
        ps.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
        float s = 0.025f;
        ps.scale(-s, -s, s);

        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buf.getBuffer(RenderType.gui());
        Matrix4f m = ps.last().pose();

        float w = AFConfig.hbWidth;
        float h = 6.0f;
        float x0 = -w / 2.0f;
        float y1 = 0.0f;          // bottom edge (y grows downwards on screen)
        float y0 = y1 - h;        // top edge

        float frac = cur / max;
        float trailFrac = Mth.clamp(trail / max, 0.0f, 1.0f);

        int fillRgb = Mth.hsvToRgb(Mth.clamp(frac, 0f, 1f) * 0.33f, 0.85f, 0.95f);

        // border + background
        quad(vc, m, x0 - 1.0f, y0 - 1.0f, x0 + w + 1.0f, y1 + 1.0f, 0.0f, 0xFF000000);
        quad(vc, m, x0, y0, x0 + w, y1, 0.3f, 0xFF3A1010);
        // recent damage (white)
        if (trailFrac > frac) {
            quad(vc, m, x0 + w * frac, y0, x0 + w * trailFrac, y1, 0.6f, 0xFFF2F2F2);
        }
        // current health
        if (frac > 0.0f) {
            quad(vc, m, x0, y0, x0 + w * frac, y1, 0.9f, 0xFF000000 | fillRgb);
            // light strip on top for a bit of depth
            quad(vc, m, x0, y0, x0 + w * frac, y0 + 1.5f, 1.2f, 0x55FFFFFF);
        }
        // absorption (gold, drawn as a thin strip under the bar)
        if (abs > 0.0f) {
            float af = Mth.clamp(abs / max, 0.0f, 1.0f);
            quad(vc, m, x0, y1 + 1.0f, x0 + w * af, y1 + 3.0f, 0.9f, 0xFFFFC21A);
        }

        if (AFConfig.hbText) {
            Font font = mc.font;
            String txt = String.format("%.0f / %.0f", cur, max);
            if (abs > 0.0f) txt += String.format(" +%.0f", abs);
            ps.pushPose();
            ps.translate(0.0f, y0 - 10.0f, 1.5f);
            ps.scale(0.8f, 0.8f, 1.0f);
            font.drawInBatch(Component.literal(txt), -font.width(txt) / 2.0f, 0.0f, 0xFFFFFFFF, true,
                    ps.last().pose(), buf, Font.DisplayMode.NORMAL, 0, 15728880);
            ps.popPose();
        }

        buf.endBatch();
        ps.popPose();
    }

    /** Fills a rectangle with both winding orders so it never gets culled. */
    private static void quad(VertexConsumer vc, Matrix4f m, float x0, float y0, float x1, float y1, float z, int argb) {
        int a = argb >>> 24 & 255;
        int r = argb >>> 16 & 255;
        int g = argb >>> 8 & 255;
        int b = argb & 255;
        vc.vertex(m, x0, y1, z).color(r, g, b, a).endVertex();
        vc.vertex(m, x1, y1, z).color(r, g, b, a).endVertex();
        vc.vertex(m, x1, y0, z).color(r, g, b, a).endVertex();
        vc.vertex(m, x0, y0, z).color(r, g, b, a).endVertex();

        vc.vertex(m, x0, y0, z).color(r, g, b, a).endVertex();
        vc.vertex(m, x1, y0, z).color(r, g, b, a).endVertex();
        vc.vertex(m, x1, y1, z).color(r, g, b, a).endVertex();
        vc.vertex(m, x0, y1, z).color(r, g, b, a).endVertex();
    }
}
