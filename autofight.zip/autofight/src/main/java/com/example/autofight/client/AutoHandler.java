package com.example.autofight.client;

import com.example.autofight.AFConfig;
import com.example.autofight.AutoFightMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/**
 * Client tick logic. Everything is done by pressing the player's OWN keybinds
 * (guard / dodge / movement), exactly like a human would, so nothing is sent
 * to the server that a normal client would not send.
 *
 * Accuracy model: for every nearby enemy we track its closing speed and its swing state
 * every tick, estimate the "time to impact" (tti, in ticks) and only react when the hit is
 * expected within the configured lead time. That way the guard / dodge window lines up with
 * the real hit instead of firing as soon as an enemy walks into range.
 */
@Mod.EventBusSubscriber(modid = AutoFightMod.MODID, value = Dist.CLIENT)
public class AutoHandler {

    private static KeyMapping guardKey;
    private static KeyMapping dodgeKey;
    private static boolean keysResolved = false;

    private static int guardTicks = 0;
    private static int guardCd = 0;
    private static int dodgeTicks = 0;
    private static int dodgeCd = 0;
    private static KeyMapping moveKeyHeld = null;
    private static boolean sideFlip = false;

    private static long tickCounter = 0;
    private static final Map<Integer, Track> tracks = new HashMap<>();

    /** Per-enemy state remembered between ticks. */
    private static class Track {
        double lastGap = Double.NaN;
        double speed = 0.0;     // smoothed closing speed, blocks / tick (>0 = approaching)
        int swingAge = 99;      // ticks since the enemy last showed an attack signal
        long lastSeen = 0;
    }

    /**
     * @param gap  edge-to-edge distance in blocks
     * @param tti  estimated ticks until the hit lands (0 = now)
     * @param side projectiles only: >0 means the projectile's path passes on my right side
     */
    private record Threat(Entity entity, double gap, double tti, boolean projectile, double side) {}

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        while (ClientSetup.OPEN_KEY.consumeClick()) {
            if (mc.screen == null && mc.player != null) mc.setScreen(new AutoFightScreen());
        }

        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null || p.isSpectator() || !p.isAlive()) {
            releaseAll();
            tracks.clear();
            return;
        }
        if (!keysResolved) resolveKeys(mc);

        tickCounter++;
        if (guardCd > 0) guardCd--;
        if (dodgeCd > 0) dodgeCd--;

        if (guardTicks > 0 && --guardTicks == 0) release(guardKey);
        if (dodgeTicks > 0 && --dodgeTicks == 0) {
            release(dodgeKey);
            release(moveKeyHeld);
            moveKeyHeld = null;
        }

        if (!AFConfig.autoParry && !AFConfig.autoDodge) {
            releaseAll();
            return;
        }

        Threat t = scan(mc, p);
        if (tickCounter % 40 == 0) {
            final long limit = tickCounter - 40;
            tracks.values().removeIf(tr -> tr.lastSeen < limit);
        }
        if (t == null) return;

        boolean canDodge = AFConfig.autoDodge && dodgeTicks == 0 && dodgeCd == 0 && dodgeKey != null;

        if (t.projectile()) {
            if (canDodge && AFConfig.dodgeProjectiles && t.tti() <= AFConfig.dodgeLead + 2) {
                startDodge(mc, p, t);
            }
            return;
        }

        boolean inParry = t.gap() <= AFConfig.parryRange && t.tti() <= AFConfig.parryLead;
        boolean inDodge = t.gap() <= AFConfig.dodgeRange && t.tti() <= AFConfig.dodgeLead;

        if (AFConfig.autoParry && guardKey != null && canGuard(p)) {
            if (guardTicks == 0 && guardCd == 0 && inParry) {
                startGuard(p, t);
            } else if (guardTicks == 0 && guardCd > 0 && canDodge && inDodge) {
                // guard is on cooldown -> dodge as a fallback
                startDodge(mc, p, t);
            }
        } else if (canDodge && inDodge) {
            startDodge(mc, p, t);
        }
    }

    // ------------------------------------------------------------ key helpers

    private static void resolveKeys(Minecraft mc) {
        keysResolved = true;
        for (KeyMapping k : mc.options.keyMappings) {
            String n = k.getName().toLowerCase();
            if (n.contains("epicfight") || n.contains("epic_fight")) {
                if (n.contains("dodge")) dodgeKey = k;
                else if (n.contains("guard")) guardKey = k;
            }
        }
        // Epic Fight guards with the normal "use" key (right click) when no dedicated key exists.
        if (guardKey == null) guardKey = mc.options.keyUse;
    }

    private static void press(KeyMapping k, boolean click) {
        if (k == null) return;
        KeyMapping.set(k.getKey(), true);
        if (click) KeyMapping.click(k.getKey());
    }

    private static void release(KeyMapping k) {
        if (k == null) return;
        if (!physicallyDown(k)) KeyMapping.set(k.getKey(), false);
    }

    private static boolean physicallyDown(KeyMapping k) {
        long w = Minecraft.getInstance().getWindow().getWindow();
        InputConstants.Key key = k.getKey();
        if (key.getType() == InputConstants.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(w, key.getValue()) == GLFW.GLFW_PRESS;
        }
        if (key.getType() == InputConstants.Type.KEYSYM) {
            return InputConstants.isKeyDown(w, key.getValue());
        }
        return false;
    }

    private static void releaseAll() {
        if (guardTicks > 0) release(guardKey);
        if (dodgeTicks > 0) {
            release(dodgeKey);
            release(moveKeyHeld);
        }
        guardTicks = 0;
        dodgeTicks = 0;
        moveKeyHeld = null;
    }

    // ---------------------------------------------------------------- actions

    private static boolean canGuard(LocalPlayer p) {
        return !p.getMainHandItem().isEmpty() || !p.getOffhandItem().isEmpty();
    }

    private static void debug(LocalPlayer p, String action, Threat t) {
        if (!AFConfig.debug) return;
        String name = t.entity().getName().getString();
        p.displayClientMessage(Component.literal(String.format(
                "%s | %s | gap %.1f | tti %.1f", action, name, t.gap(), t.tti())), true);
    }

    private static void startGuard(LocalPlayer p, Threat t) {
        press(guardKey, true);
        guardTicks = Math.max(2, AFConfig.guardHold);
        guardCd = guardTicks + AFConfig.cooldown;
        debug(p, "PARRY", t);
    }

    private static void startDodge(Minecraft mc, LocalPlayer p, Threat t) {
        KeyMapping move = chooseMoveKey(mc, p, t);
        // Epic Fight reads the movement input to decide the dodge direction.
        press(move, false);
        press(dodgeKey, true);
        moveKeyHeld = move;
        dodgeTicks = 3;
        dodgeCd = 14 + AFConfig.cooldown;
        debug(p, "DODGE", t);
    }

    /** Side key that moves AWAY from where the threat comes from. */
    private static KeyMapping sideKey(Minecraft mc, LocalPlayer p, Threat t) {
        if (t.projectile()) {
            // path passes on my right -> step left to widen the miss, and vice versa
            return t.side() > 0 ? mc.options.keyLeft : mc.options.keyRight;
        }
        double right = attackerRight(p, t.entity());
        if (Math.abs(right) < 0.25) {
            sideFlip = !sideFlip;
            return sideFlip ? mc.options.keyLeft : mc.options.keyRight;
        }
        return right > 0 ? mc.options.keyLeft : mc.options.keyRight;
    }

    /** Component of the direction to the attacker along my right-hand side (-1..1). */
    private static double attackerRight(LocalPlayer p, Entity en) {
        Vec3 look = p.getLookAngle();
        double fl = Math.sqrt(look.x * look.x + look.z * look.z);
        double tx = en.getX() - p.getX(), tz = en.getZ() - p.getZ();
        double tl = Math.sqrt(tx * tx + tz * tz);
        if (fl < 1.0E-4 || tl < 1.0E-4) return 0.0;
        double fx = look.x / fl, fz = look.z / fl;
        tx /= tl;
        tz /= tl;
        return -fz * tx + fx * tz;
    }

    /** Component of the direction to the attacker along my forward direction (-1..1). */
    private static double attackerFront(LocalPlayer p, Entity en) {
        Vec3 look = p.getLookAngle();
        double fl = Math.sqrt(look.x * look.x + look.z * look.z);
        double tx = en.getX() - p.getX(), tz = en.getZ() - p.getZ();
        double tl = Math.sqrt(tx * tx + tz * tz);
        if (fl < 1.0E-4 || tl < 1.0E-4) return 1.0;
        return (look.x / fl) * (tx / tl) + (look.z / fl) * (tz / tl);
    }

    private static KeyMapping chooseMoveKey(Minecraft mc, LocalPlayer p, Threat t) {
        switch (AFConfig.dodgeDir) {
            case 0:
                return mc.options.keyDown;
            case 1:
                return sideKey(mc, p, t);
            default: {
                if (t.projectile()) return sideKey(mc, p, t);
                // attacker behind me -> roll forward, otherwise sidestep away from the swing
                if (attackerFront(p, t.entity()) < -0.45) return mc.options.keyUp;
                return sideKey(mc, p, t);
            }
        }
    }

    // --------------------------------------------------------------- scanning

    private static Threat scan(Minecraft mc, LocalPlayer p) {
        double reach = Math.max(Math.max(AFConfig.parryRange, AFConfig.dodgeRange), 8.0);
        AABB box = p.getBoundingBox().inflate(reach, 3.0, reach);
        Threat best = null;
        for (Entity en : mc.level.getEntities(p, box)) {
            Threat c = null;
            if (en instanceof Projectile pr) {
                if (!AFConfig.autoDodge || !AFConfig.dodgeProjectiles) continue;
                c = projectileThreat(p, pr);
            } else if (en instanceof LivingEntity le && le.isAlive() && validTarget(p, le)) {
                c = meleeThreat(p, le);
            }
            if (c == null) continue;
            if (best == null || c.tti() < best.tti() || (c.tti() == best.tti() && c.gap() < best.gap())) {
                best = c;
            }
        }
        return best;
    }

    private static boolean validTarget(LocalPlayer p, LivingEntity le) {
        if (le == p) return false;
        if (le instanceof TamableAnimal ta && ta.isOwnedBy(p)) return false;
        switch (AFConfig.targetMode) {
            case 0:
                return le instanceof Enemy;
            case 1:
                return le instanceof Mob;
            default:
                return le instanceof Mob || le instanceof Player;
        }
    }

    private static Threat meleeThreat(LocalPlayer p, LivingEntity le) {
        double dx = p.getX() - le.getX();
        double dz = p.getZ() - le.getZ();
        double flat = Math.sqrt(dx * dx + dz * dz);
        if (flat < 1.0E-4) return null;
        if (Math.abs(p.getY() - le.getY()) > 3.0) return null;

        double gap = Math.max(0.0, flat - (le.getBbWidth() + p.getBbWidth()) * 0.5);

        // ---- update this enemy's track (runs every tick for every nearby enemy)
        Track tr = tracks.computeIfAbsent(le.getId(), k -> new Track());
        double v = 0.0;
        if (!Double.isNaN(tr.lastGap)) {
            double vNew = tr.lastGap - gap;
            v = 0.5 * vNew + 0.5 * tr.speed;
        }
        tr.lastGap = gap;
        tr.speed = v;
        tr.lastSeen = tickCounter;
        if (le.swinging || le.attackAnim > 0.0f || le.isUsingItem()) tr.swingAge = 0;
        else if (tr.swingAge < 99) tr.swingAge++;

        // ---- filters
        if (gap > Math.max(AFConfig.parryRange, AFConfig.dodgeRange)) return null;
        if (!p.hasLineOfSight(le)) return null;

        // is the enemy looking at me? (head direction, tighter cone the farther away it is)
        double yaw = Math.toRadians(le.yHeadRot);
        double lx = -Math.sin(yaw), lz = Math.cos(yaw);
        double dot = (lx * dx + lz * dz) / flat;
        if (dot < (gap < 1.0 ? 0.0 : 0.5)) return null;

        // ---- attack signal
        boolean swing = tr.swingAge <= 10;
        boolean charging = v > 0.10;
        if (AFConfig.detectMode == 0 && !swing && !charging) return null;

        // ---- time to impact
        double reach = AFConfig.enemyReach;
        double tti;
        if (gap <= reach) {
            tti = 0.0;
        } else {
            double closing = Math.max(v, swing ? 0.12 : 0.05);
            tti = (gap - reach) / closing;
        }
        if (swing && gap <= reach + 1.0) tti = 0.0;

        return new Threat(le, gap, tti, false, 0.0);
    }

    private static Threat projectileThreat(LocalPlayer p, Projectile pr) {
        if (pr.getOwner() == p) return null;
        Vec3 vel = pr.getDeltaMovement();
        double sp = vel.length();
        if (sp < 0.2) return null; // stuck / on the ground

        Vec3 mid = p.position().add(0, p.getBbHeight() * 0.5, 0);
        Vec3 to = mid.subtract(pr.position());
        double along = to.dot(vel) / sp;
        if (along <= 0) return null; // moving away
        double dist = to.length();
        if (dist > 16.0) return null;

        Vec3 closest = pr.position().add(vel.scale(along / sp));
        Vec3 miss = closest.subtract(mid);
        if (miss.length() > 1.4) return null; // will pass by

        double tti = along / sp;

        Vec3 look = p.getLookAngle();
        double fl = Math.sqrt(look.x * look.x + look.z * look.z);
        double side = 0.0;
        if (fl > 1.0E-4) {
            side = miss.x * (-look.z / fl) + miss.z * (look.x / fl);
        }
        return new Threat(pr, dist, tti, true, side);
    }
}
