package com.example.autofight.client;

import com.example.autofight.AFConfig;
import com.example.autofight.AutoFightMod;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

/**
 * Client tick logic. Everything is done by pressing the player's OWN keybinds
 * (guard / dodge / movement), exactly like a human would, so nothing is sent
 * to the server that a normal client would not send.
 */
@Mod.EventBusSubscriber(modid = AutoFightMod.MODID, value = Dist.CLIENT)
public class AutoHandler {

    private static KeyMapping guardKey;
    private static KeyMapping dodgeKey;
    private static boolean keysResolved = false;

    private static int guardTicks = 0;
    private static int guardCd = 0;
    private static int dodgeTicks = 0;
    private static int dodgeCd = 0;
    private static KeyMapping moveKeyHeld = null;
    private static boolean sideFlip = false;

    private record Threat(Entity entity, double dist, boolean projectile) {}

    // ------------------------------------------------------------------ tick

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();

        while (ClientSetup.OPEN_KEY.consumeClick()) {
            if (mc.screen == null && mc.player != null) mc.setScreen(new AutoFightScreen());
        }

        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.screen != null || p.isSpectator() || !p.isAlive()) {
            releaseAll();
            return;
        }
        if (!keysResolved) resolveKeys(mc);

        if (guardCd > 0) guardCd--;
        if (dodgeCd > 0) dodgeCd--;

        if (guardTicks > 0 && --guardTicks == 0) release(guardKey);
        if (dodgeTicks > 0 && --dodgeTicks == 0) {
            release(dodgeKey);
            release(moveKeyHeld);
            moveKeyHeld = null;
        }

        if (!AFConfig.autoParry && !AFConfig.autoDodge) {
            releaseAll();
            return;
        }

        Threat t = scan(mc, p);
        if (t == null) return;

        if (t.projectile()) {
            if (AFConfig.autoDodge && AFConfig.dodgeProjectiles && dodgeTicks == 0 && dodgeCd == 0 && dodgeKey != null) {
                startDodge(mc, p, t);
            }
            return;
        }

        if (AFConfig.autoParry && guardKey != null && canGuard(p)) {
            if (guardTicks == 0 && guardCd == 0 && t.dist() <= AFConfig.parryRange) {
                startGuard();
            } else if (guardTicks == 0 && AFConfig.autoDodge && dodgeTicks == 0 && dodgeCd == 0
                    && dodgeKey != null && t.dist() <= AFConfig.dodgeRange) {
                // guard is on cooldown -> dodge as a fallback
                startDodge(mc, p, t);
            }
        } else if (AFConfig.autoDodge && dodgeTicks == 0 && dodgeCd == 0
                && dodgeKey != null && t.dist() <= AFConfig.dodgeRange) {
            startDodge(mc, p, t);
        }
    }

    // ------------------------------------------------------------ key helpers

    private static void resolveKeys(Minecraft mc) {
        keysResolved = true;
        for (KeyMapping k : mc.options.keyMappings) {
            String n = k.getName().toLowerCase();
            if (n.contains("epicfight") || n.contains("epic_fight")) {
                if (n.contains("dodge")) dodgeKey = k;
                else if (n.contains("guard")) guardKey = k;
            }
        }
        // Epic Fight guards with the normal "use" key (right click) when no dedicated key exists.
        if (guardKey == null) guardKey = mc.options.keyUse;
    }

    private static void press(KeyMapping k, boolean click) {
        if (k == null) return;
        KeyMapping.set(k.getKey(), true);
        if (click) KeyMapping.click(k.getKey());
    }

    private static void release(KeyMapping k) {
        if (k == null) return;
        if (!physicallyDown(k)) KeyMapping.set(k.getKey(), false);
    }

    private static boolean physicallyDown(KeyMapping k) {
        long w = Minecraft.getInstance().getWindow().getWindow();
        InputConstants.Key key = k.getKey();
        if (key.getType() == InputConstants.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(w, key.getValue()) == GLFW.GLFW_PRESS;
        }
        if (key.getType() == InputConstants.Type.KEYSYM) {
            return InputConstants.isKeyDown(w, key.getValue());
        }
        return false;
    }

    private static void releaseAll() {
        if (guardTicks > 0) release(guardKey);
        if (dodgeTicks > 0) {
            release(dodgeKey);
            release(moveKeyHeld);
        }
        guardTicks = 0;
        dodgeTicks = 0;
        moveKeyHeld = null;
    }

    // ---------------------------------------------------------------- actions

    private static boolean canGuard(LocalPlayer p) {
        return !p.getMainHandItem().isEmpty() || !p.getOffhandItem().isEmpty();
    }

    private static void startGuard() {
        press(guardKey, true);
        guardTicks = Math.max(2, AFConfig.guardHold);
        guardCd = guardTicks + AFConfig.cooldown;
    }

    private static void startDodge(Minecraft mc, LocalPlayer p, Threat t) {
        KeyMapping move = chooseMoveKey(mc, p, t);
        // Epic Fight reads the movement input to decide the dodge direction.
        press(move, false);
        press(dodgeKey, true);
        moveKeyHeld = move;
        dodgeTicks = 3;
        dodgeCd = 14 + AFConfig.cooldown;
    }

    private static KeyMapping chooseMoveKey(Minecraft mc, LocalPlayer p, Threat t) {
        switch (AFConfig.dodgeDir) {
            case 0:
                return mc.options.keyDown;
            case 1:
                sideFlip = !sideFlip;
                return sideFlip ? mc.options.keyLeft : mc.options.keyRight;
            default: {
                Vec3 to = t.entity().position().subtract(p.position());
                Vec3 look = p.getLookAngle();
                double fx = look.x, fz = look.z;
                double fl = Math.sqrt(fx * fx + fz * fz);
                if (fl < 1.0E-4) return mc.options.keyDown;
                fx /= fl;
                fz /= fl;
                double tl = Math.sqrt(to.x * to.x + to.z * to.z);
                if (tl < 1.0E-4) return mc.options.keyDown;
                double tx = to.x / tl, tz = to.z / tl;
                double front = fx * tx + fz * tz;      // >0 attacker in front of me
                double right = -fz * tx + fx * tz;     // sign picks the side
                if (front > 0.45) return mc.options.keyDown;
                if (front < -0.45) return mc.options.keyUp;
                return right > 0 ? mc.options.keyLeft : mc.options.keyRight;
            }
        }
    }

    // --------------------------------------------------------------- scanning

    private static Threat scan(Minecraft mc, LocalPlayer p) {
        double reach = Math.max(Math.max(AFConfig.parryRange, AFConfig.dodgeRange), 7.0);
        AABB box = p.getBoundingBox().inflate(reach, 3.0, reach);
        Threat best = null;
        for (Entity en : mc.level.getEntities(p, box)) {
            Threat c = null;
            if (en instanceof Projectile pr) {
                if (!AFConfig.autoDodge || !AFConfig.dodgeProjectiles) continue;
                c = projectileThreat(p, pr);
            } else if (en instanceof LivingEntity le && le.isAlive() && validTarget(p, le)) {
                c = meleeThreat(p, le);
            }
            if (c != null && (best == null || c.dist() < best.dist())) best = c;
        }
        return best;
    }

    private static boolean validTarget(LocalPlayer p, LivingEntity le) {
        if (le == p) return false;
        if (le instanceof TamableAnimal ta && ta.isOwnedBy(p)) return false;
        switch (AFConfig.targetMode) {
            case 0:
                return le instanceof Enemy;
            case 1:
                return le instanceof Mob;
            default:
                return le instanceof Mob || le instanceof Player;
        }
    }

    private static Threat meleeThreat(LocalPlayer p, LivingEntity le) {
        double dx = p.getX() - le.getX();
        double dz = p.getZ() - le.getZ();
        double flat = Math.sqrt(dx * dx + dz * dz);
        if (flat < 1.0E-4) return null;
        if (Math.abs(p.getY() - le.getY()) > 3.0) return null;

        double dist = flat - (le.getBbWidth() + p.getBbWidth()) * 0.5;
        if (dist > Math.max(AFConfig.parryRange, AFConfig.dodgeRange)) return null;

        // is the enemy facing me?
        Vec3 look = le.getViewVector(1.0f);
        double dot = (look.x * dx + look.z * dz) / (flat * Math.max(1.0E-4, Math.sqrt(look.x * look.x + look.z * look.z)));
        if (dot < 0.35) return null;

        if (AFConfig.detectMode == 0) {
            boolean attacking = le.swinging || le.attackAnim > 0.0f || le.isUsingItem();
            double pdx = p.xo - le.xo, pdz = p.zo - le.zo;
            double prevFlat = Math.sqrt(pdx * pdx + pdz * pdz);
            boolean closing = (prevFlat - flat) > 0.08;
            if (!attacking && !closing) return null;
        }
        return new Threat(le, Math.max(0.0, dist), false);
    }

    private static Threat projectileThreat(LocalPlayer p, Projectile pr) {
        if (pr.getOwner() == p) return null;
        Vec3 vel = pr.getDeltaMovement();
        double speed2 = vel.lengthSqr();
        if (speed2 < 0.04) return null; // stuck / on the ground
        Vec3 to = p.position().add(0, p.getBbHeight() * 0.5, 0).subtract(pr.position());
        double dist = to.length();
        if (dist > 7.0) return null;
        double along = to.dot(vel) / Math.sqrt(speed2);
        if (along <= 0) return null; // moving away
        double missSq = to.lengthSqr() - along * along;
        if (missSq > 1.6 * 1.6) return null; // will pass by
        return new Threat(pr, dist, true);
    }
}
