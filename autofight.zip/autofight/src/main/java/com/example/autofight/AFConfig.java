package com.example.autofight;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple properties-file config stored in config/autofight.properties */
public class AFConfig {
    public static boolean autoParry = false;
    public static boolean autoDodge = false;
    public static boolean dodgeProjectiles = true;

    /** Distance (blocks) at which an enemy triggers the parry. */
    public static float parryRange = 4.0f;
    /** Distance (blocks) at which an enemy triggers the dodge. */
    public static float dodgeRange = 3.0f;
    /** How many ticks the guard is held per parry (20 ticks = 1 second). */
    public static int guardHold = 8;
    /** Ticks to wait between two automatic actions. */
    public static int cooldown = 6;

    /** 0 = Smart (swing / fast approach), 1 = Proximity (anything close and facing me) */
    public static int detectMode = 0;
    /** 0 = Hostile mobs, 1 = All mobs, 2 = Mobs + Players */
    public static int targetMode = 0;
    /** 0 = Backward, 1 = Sideways, 2 = Away from attacker */
    public static int dodgeDir = 2;

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("autofight.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            save();
            return;
        }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f)) {
            p.load(r);
        } catch (IOException e) {
            return;
        }
        autoParry = bool(p, "autoParry", autoParry);
        autoDodge = bool(p, "autoDodge", autoDodge);
        dodgeProjectiles = bool(p, "dodgeProjectiles", dodgeProjectiles);
        parryRange = flt(p, "parryRange", parryRange, 1f, 8f);
        dodgeRange = flt(p, "dodgeRange", dodgeRange, 1f, 8f);
        guardHold = (int) flt(p, "guardHold", guardHold, 2, 30);
        cooldown = (int) flt(p, "cooldown", cooldown, 0, 40);
        detectMode = (int) flt(p, "detectMode", detectMode, 0, 1);
        targetMode = (int) flt(p, "targetMode", targetMode, 0, 2);
        dodgeDir = (int) flt(p, "dodgeDir", dodgeDir, 0, 2);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("autoParry", String.valueOf(autoParry));
        p.setProperty("autoDodge", String.valueOf(autoDodge));
        p.setProperty("dodgeProjectiles", String.valueOf(dodgeProjectiles));
        p.setProperty("parryRange", String.valueOf(parryRange));
        p.setProperty("dodgeRange", String.valueOf(dodgeRange));
        p.setProperty("guardHold", String.valueOf(guardHold));
        p.setProperty("cooldown", String.valueOf(cooldown));
        p.setProperty("detectMode", String.valueOf(detectMode));
        p.setProperty("targetMode", String.valueOf(targetMode));
        p.setProperty("dodgeDir", String.valueOf(dodgeDir));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "AutoFight client config");
        } catch (IOException ignored) {
        }
    }

    private static boolean bool(Properties p, String k, boolean def) {
        String v = p.getProperty(k);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    private static float flt(Properties p, String k, float def, float min, float max) {
        try {
            float v = Float.parseFloat(p.getProperty(k, String.valueOf(def)));
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
