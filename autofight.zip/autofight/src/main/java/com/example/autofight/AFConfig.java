package com.example.autofight;

import net.minecraftforge.fml.loading.FMLPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Simple properties-file config stored in config/autofight.properties */
public class AFConfig {
    public static boolean autoParry = false;
    public static boolean autoDodge = false;
    public static boolean dodgeProjectiles = true;

    /** Distance (blocks) at which an enemy triggers the parry. */
    public static float parryRange = 4.0f;
    /** Distance (blocks) at which an enemy triggers the dodge. */
    public static float dodgeRange = 3.0f;
    /** How many ticks the guard is held per parry (20 ticks = 1 second). */
    public static int guardHold = 8;
    /** Ticks to wait between two automatic actions. */
    public static int cooldown = 6;

    /** 0 = Smart (swing / fast approach), 1 = Proximity (anything close and facing me) */
    public static int detectMode = 0;
    /** 0 = Hostile mobs, 1 = All mobs, 2 = Mobs + Players */
    public static int targetMode = 0;
    /** 0 = Backward, 1 = Sideways, 2 = Away from attacker */
    public static int dodgeDir = 2;

    /** How far (blocks, edge to edge) an enemy can hit you from. */
    public static float enemyReach = 2.5f;
    /** Guard is raised when the hit is expected within this many ticks. */
    public static int parryLead = 4;
    /** Dodge is pressed when the hit is expected within this many ticks. */
    public static int dodgeLead = 3;
    /** Shows what the mod detected on the action bar (for tuning). */
    public static boolean debug = false;
    /** Read the real attack phase from Epic Fight (wind-up / hit / recovery) when available. */
    public static boolean useEpicFightPhase = true;

    // ---- floating health bar above your own head
    public static boolean healthBar = true;
    public static boolean hbText = true;
    public static boolean hbHideFull = false;
    public static int hbWidth = 50;
    public static float hbOffset = 0.5f;

    private static Path file() {
        return FMLPaths.CONFIGDIR.get().resolve("autofight.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            save();
            return;
        }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f)) {
            p.load(r);
        } catch (IOException e) {
            return;
        }
        autoParry = bool(p, "autoParry", autoParry);
        autoDodge = bool(p, "autoDodge", autoDodge);
        dodgeProjectiles = bool(p, "dodgeProjectiles", dodgeProjectiles);
        parryRange = flt(p, "parryRange", parryRange, 1f, 8f);
        dodgeRange = flt(p, "dodgeRange", dodgeRange, 1f, 8f);
        guardHold = (int) flt(p, "guardHold", guardHold, 2, 30);
        cooldown = (int) flt(p, "cooldown", cooldown, 0, 40);
        detectMode = (int) flt(p, "detectMode", detectMode, 0, 1);
        targetMode = (int) flt(p, "targetMode", targetMode, 0, 2);
        dodgeDir = (int) flt(p, "dodgeDir", dodgeDir, 0, 2);
        enemyReach = flt(p, "enemyReach", enemyReach, 1f, 6f);
        parryLead = (int) flt(p, "parryLead", parryLead, 0, 10);
        dodgeLead = (int) flt(p, "dodgeLead", dodgeLead, 0, 10);
        debug = bool(p, "debug", debug);
        useEpicFightPhase = bool(p, "useEpicFightPhase", useEpicFightPhase);
        healthBar = bool(p, "healthBar", healthBar);
        hbText = bool(p, "hbText", hbText);
        hbHideFull = bool(p, "hbHideFull", hbHideFull);
        hbWidth = (int) flt(p, "hbWidth", hbWidth, 20, 100);
        hbOffset = flt(p, "hbOffset", hbOffset, 0f, 1.5f);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("autoParry", String.valueOf(autoParry));
        p.setProperty("autoDodge", String.valueOf(autoDodge));
        p.setProperty("dodgeProjectiles", String.valueOf(dodgeProjectiles));
        p.setProperty("parryRange", String.valueOf(parryRange));
        p.setProperty("dodgeRange", String.valueOf(dodgeRange));
        p.setProperty("guardHold", String.valueOf(guardHold));
        p.setProperty("cooldown", String.valueOf(cooldown));
        p.setProperty("detectMode", String.valueOf(detectMode));
        p.setProperty("targetMode", String.valueOf(targetMode));
        p.setProperty("dodgeDir", String.valueOf(dodgeDir));
        p.setProperty("enemyReach", String.valueOf(enemyReach));
        p.setProperty("parryLead", String.valueOf(parryLead));
        p.setProperty("dodgeLead", String.valueOf(dodgeLead));
        p.setProperty("debug", String.valueOf(debug));
        p.setProperty("useEpicFightPhase", String.valueOf(useEpicFightPhase));
        p.setProperty("healthBar", String.valueOf(healthBar));
        p.setProperty("hbText", String.valueOf(hbText));
        p.setProperty("hbHideFull", String.valueOf(hbHideFull));
        p.setProperty("hbWidth", String.valueOf(hbWidth));
        p.setProperty("hbOffset", String.valueOf(hbOffset));
        try (Writer w = Files.newBufferedWriter(file())) {
            p.store(w, "AutoFight client config");
        } catch (IOException ignored) {
        }
    }

    private static boolean bool(Properties p, String k, boolean def) {
        String v = p.getProperty(k);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    private static float flt(Properties p, String k, float def, float min, float max) {
        try {
            float v = Float.parseFloat(p.getProperty(k, String.valueOf(def)));
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
