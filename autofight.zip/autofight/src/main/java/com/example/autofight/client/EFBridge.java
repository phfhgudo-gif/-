package com.example.autofight.client;

import net.minecraft.world.entity.Entity;

import java.lang.reflect.Method;

/**
 * Optional, reflection-only bridge to Epic Fight. There is NO compile-time dependency, so the
 * mod still loads and works (with the heuristic detector) if Epic Fight is missing or its API
 * is different. Every call is wrapped in try/catch and returns "unavailable" on any problem.
 *
 * It reads the real combat state Epic Fight keeps for every entity:
 *   EntityState.attacking()  -> the hit is active right now
 *   EntityState.getLevel()   -> attack phase: 1 = anticipation (wind-up), 2 = attack, 3 = recovery
 */
final class EFBridge {
    private static boolean tried = false;
    private static boolean ok = false;

    private static Method getEntityPatch;     // static EpicFightCapabilities.getEntityPatch(Entity, Class)
    private static Class<?> livingPatchClass;
    private static Method getEntityState;     // LivingEntityPatch.getEntityState()
    private static Method stLevel;            // EntityState.getLevel()
    private static Method stAttacking;        // EntityState.attacking()
    private static Method stHurt;             // EntityState.hurt()
    private static Method stKnockDown;        // EntityState.knockDown()

    private EFBridge() {}

    private static void init() {
        if (tried) return;
        tried = true;
        try {
            Class<?> caps = Class.forName("yesman.epicfight.world.capabilities.EpicFightCapabilities");
            livingPatchClass = Class.forName("yesman.epicfight.world.capabilities.entitypatch.LivingEntityPatch");
            Class<?> state = Class.forName("yesman.epicfight.api.animation.types.EntityState");

            for (Method m : caps.getMethods()) {
                if (m.getName().equals("getEntityPatch") && m.getParameterCount() == 2
                        && java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                    getEntityPatch = m;
                    break;
                }
            }
            getEntityState = livingPatchClass.getMethod("getEntityState");
            stLevel = state.getMethod("getLevel");
            stAttacking = state.getMethod("attacking");
            try {
                stHurt = state.getMethod("hurt");
                stKnockDown = state.getMethod("knockDown");
            } catch (Throwable ignored) {
                stHurt = null;
                stKnockDown = null;
            }
            ok = getEntityPatch != null;
        } catch (Throwable t) {
            ok = false;
        }
    }

    static boolean available() {
        init();
        return ok;
    }

    private static Object stateOf(Entity e) {
        try {
            Object patch = getEntityPatch.invoke(null, e, livingPatchClass);
            if (patch == null) return null;
            return getEntityState.invoke(patch);
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * @return -1 = Epic Fight data not available for this entity,
     *          0 = idle, 1 = wind-up, 2 = hit active, 3 = recovery
     */
    static int attackPhase(Entity e) {
        init();
        if (!ok) return -1;
        Object st = stateOf(e);
        if (st == null) return -1;
        try {
            if ((Boolean) stAttacking.invoke(st)) return 2;
            int lv = ((Number) stLevel.invoke(st)).intValue();
            if (lv <= 0) return 0;
            return Math.min(lv, 3);
        } catch (Throwable t) {
            return -1;
        }
    }

    /** True while the player is staggered / knocked down, so a guard or dodge would not work. */
    static boolean selfBusy(Entity player) {
        init();
        if (!ok || stHurt == null || stKnockDown == null) return false;
        Object st = stateOf(player);
        if (st == null) return false;
        try {
            return (Boolean) stHurt.invoke(st) || (Boolean) stKnockDown.invoke(st);
        } catch (Throwable t) {
            return false;
        }
    }
}
