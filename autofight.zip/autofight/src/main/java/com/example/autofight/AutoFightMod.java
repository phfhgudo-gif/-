package com.example.autofight;

import net.minecraftforge.fml.common.Mod;

/**
 * Client-side only mod. All real logic lives in the client package, which is only
 * registered on Dist.CLIENT, so a dedicated server never loads it.
 */
@Mod(AutoFightMod.MODID)
public class AutoFightMod {
    public static final String MODID = "autofight";

    public AutoFightMod() {
        AFConfig.load();
    }
}
