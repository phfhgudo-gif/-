package com.example.autoparry;

import com.example.autoparry.client.ClientInit;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** Client-side only. Must not reference any client-only class directly. */
@Mod(AutoParryMod.MOD_ID)
public class AutoParryMod {
    public static final String MOD_ID = "autoparry";

    public AutoParryMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, AutoParryConfig.SPEC);
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientInit::register);
    }
}
