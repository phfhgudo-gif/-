package com.example.autoparry.client;

import com.example.autoparry.AutoParryMod;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = AutoParryMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void onRegisterKeys(RegisterKeyMappingsEvent event) {
        event.register(AutoParryKeys.ENABLE);
        event.register(AutoParryKeys.DISABLE);
        event.register(AutoParryKeys.DODGE_ENABLE);
        event.register(AutoParryKeys.DODGE_DISABLE);
        event.register(AutoParryKeys.OPEN_MENU);
    }
}
