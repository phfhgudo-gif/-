package com.example.autoparry.client;

import com.example.autoparry.AutoParryConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.CommonComponents;
import net.minecraft.network.chat.Component;

/**
 * Menu made of dark rows: a switch for each feature (On = green, Off = dark) and a slider
 * for each trigger range (in blocks). Clicking a switch row flips it; dragging a slider
 * changes the range and saves it to the config file when released.
 */
public class AutoParryScreen extends Screen {
    private static final int BG_ROW = 0xFF161616;
    private static final int BG_ROW_HOVER = 0xFF202020;
    private static final int BORDER = 0xFF000000;
    private static final int GREEN = 0xFF2ED12E;
    private static final int GREEN_DARK = 0xFF1B7F1B;
    private static final int OFF_TRACK = 0xFF2B2B2B;
    private static final int KNOB = 0xFFFFFFFF;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int SUBTEXT = 0xFFAAAAAA;

    private static final int ROWS = 4;

    private final Screen parent;

    // layout (recomputed in init)
    private int panelX;
    private int panelW;
    private int rowH;
    private int rowGap;
    private int firstRowY;

    private int draggingRow = -1;

    public AutoParryScreen(Screen parent) {
        super(Component.translatable("gui.autoparry.title"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        panelW = Math.min(this.width - 16, 320);
        panelX = this.width / 2 - panelW / 2;
        rowGap = 3;
        rowH = Math.max(24, Math.min(34, (this.height - 80) / ROWS - rowGap));
        int total = 18 + ROWS * (rowH + rowGap) + 24;
        int top = Math.max(4, (this.height - total) / 2);
        firstRowY = top + 18;

        int doneY = firstRowY + ROWS * (rowH + rowGap) + 4;
        this.addRenderableWidget(Button.builder(CommonComponents.GUI_DONE, b -> this.onClose())
                .bounds(this.width / 2 - 60, doneY, 120, 20).build());
    }

    // ---------------------------------------------------------------- row data

    private boolean isToggleRow(int row) {
        return row == 0 || row == 2;
    }

    private boolean toggleState(int row) {
        return row == 0 ? AutoParryHandler.isEnabled() : AutoDodgeHandler.isEnabled();
    }

    private void flipToggle(int row) {
        if (row == 0) {
            AutoParryHandler.setEnabledState(!AutoParryHandler.isEnabled());
        } else {
            AutoDodgeHandler.setEnabledState(!AutoDodgeHandler.isEnabled());
        }
    }

    private String title(int row) {
        switch (row) {
            case 0: return Component.translatable("gui.autoparry.parry").getString();
            case 1: return Component.translatable("gui.autoparry.parry_range").getString();
            case 2: return Component.translatable("gui.autoparry.dodge").getString();
            default: return Component.translatable("gui.autoparry.dodge_range").getString();
        }
    }

    private String subtitle(int row) {
        switch (row) {
            case 0: return Component.translatable("gui.autoparry.parry.desc").getString();
            case 1: return Component.translatable("gui.autoparry.range.desc").getString();
            case 2: return Component.translatable("gui.autoparry.dodge.desc").getString();
            default: return Component.translatable("gui.autoparry.range.desc").getString();
        }
    }

    private double minValue(int row) {
        return 1.0D;
    }

    private double maxValue(int row) {
        return row == 1 ? 10.0D : 8.0D;
    }

    private double getValue(int row) {
        return row == 1 ? AutoParryConfig.TRIGGER_RANGE.get() : AutoParryConfig.DODGE_RANGE.get();
    }

    private void setValue(int row, double v) {
        v = Math.max(minValue(row), Math.min(maxValue(row), v));
        v = Math.round(v * 2.0D) / 2.0D; // steps of 0.5 block
        try {
            if (row == 1) {
                AutoParryConfig.TRIGGER_RANGE.set(v);
            } else {
                AutoParryConfig.DODGE_RANGE.set(v);
            }
        } catch (Exception ignored) {
            // config not ready: ignore
        }
    }

    private void saveConfig() {
        try {
            AutoParryConfig.TRIGGER_RANGE.save();
            AutoParryConfig.DODGE_RANGE.save();
        } catch (Exception ignored) {
            // best effort
        }
    }

    // ---------------------------------------------------------------- geometry

    private int rowY(int row) {
        return firstRowY + row * (rowH + rowGap);
    }

    private int switchW() {
        return 40;
    }

    private int switchH() {
        return 18;
    }

    private int sliderTrackW() {
        return Math.max(60, Math.min(110, panelW / 3));
    }

    private int sliderTrackX() {
        return panelX + panelW - 8 - sliderTrackW();
    }

    private int rowAt(double mx, double my) {
        if (mx < panelX || mx > panelX + panelW) return -1;
        for (int i = 0; i < ROWS; i++) {
            int y = rowY(i);
            if (my >= y && my < y + rowH) return i;
        }
        return -1;
    }

    // ---------------------------------------------------------------- render

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);

        g.drawCenteredString(this.font, Component.literal(this.title.getString()).withStyle(ChatFormatting.BOLD),
                this.width / 2, firstRowY - 14, TEXT);

        for (int i = 0; i < ROWS; i++) {
            drawRow(g, i, mouseX, mouseY);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void drawRow(GuiGraphics g, int row, int mouseX, int mouseY) {
        int y = rowY(row);
        boolean hover = rowAt(mouseX, mouseY) == row;

        g.fill(panelX - 1, y - 1, panelX + panelW + 1, y + rowH + 1, BORDER);
        g.fill(panelX, y, panelX + panelW, y + rowH, hover ? BG_ROW_HOVER : BG_ROW);

        int controlW = isToggleRow(row) ? switchW() : sliderTrackW() + 38;
        int textMax = panelW - controlW - 24;

        String t = this.font.plainSubstrByWidth(title(row), textMax);
        g.drawString(this.font, Component.literal(t).withStyle(ChatFormatting.BOLD), panelX + 8, y + 5, TEXT);
        String s = this.font.plainSubstrByWidth(subtitle(row), textMax);
        g.drawString(this.font, s, panelX + 8, y + 5 + 11, SUBTEXT);

        if (isToggleRow(row)) {
            drawSwitch(g, row, y);
        } else {
            drawSlider(g, row, y);
        }
    }

    private void drawSwitch(GuiGraphics g, int row, int y) {
        boolean on = toggleState(row);
        int w = switchW();
        int h = switchH();
        int x = panelX + panelW - 8 - w;
        int cy = y + (rowH - h) / 2;

        g.fill(x - 1, cy - 1, x + w + 1, cy + h + 1, BORDER);
        g.fill(x, cy, x + w, cy + h, on ? GREEN_DARK : OFF_TRACK);
        if (on) {
            g.fill(x, cy, x + w, cy + h / 2, GREEN);
        }
        int knobW = 14;
        int kx = on ? x + w - knobW - 2 : x + 2;
        g.fill(kx, cy + 2, kx + knobW, cy + h - 2, KNOB);
    }

    private void drawSlider(GuiGraphics g, int row, int y) {
        double min = minValue(row);
        double max = maxValue(row);
        double v = getValue(row);
        double frac = (v - min) / (max - min);
        frac = Math.max(0.0D, Math.min(1.0D, frac));

        int tw = sliderTrackW();
        int tx = sliderTrackX();
        int th = 12;
        int ty = y + (rowH - th) / 2;

        // value box
        int boxW = 30;
        int bx = tx - 6 - boxW;
        g.fill(bx - 1, ty - 3, bx + boxW + 1, ty + th + 3, BORDER);
        g.fill(bx, ty - 2, bx + boxW, ty + th + 2, 0xFF0D0D0D);
        String num = String.format(java.util.Locale.ROOT, "%.1f", v);
        g.drawCenteredString(this.font, Component.literal(num).withStyle(ChatFormatting.BOLD),
                bx + boxW / 2, ty + 2, TEXT);

        // track
        g.fill(tx - 1, ty - 1, tx + tw + 1, ty + th + 1, BORDER);
        g.fill(tx, ty, tx + tw, ty + th, OFF_TRACK);
        int fillW = (int) Math.round(frac * (tw - 8)) + 8;
        g.fill(tx, ty, tx + fillW, ty + th, GREEN_DARK);
        g.fill(tx, ty, tx + fillW, ty + th / 2, GREEN);
        // knob
        int kx = tx + fillW - 8;
        g.fill(kx, ty - 2, kx + 8, ty + th + 2, KNOB);
    }

    // ---------------------------------------------------------------- input

    private void updateSliderFromMouse(int row, double mx) {
        int tx = sliderTrackX();
        int tw = sliderTrackW();
        // knob is 8 wide, so usable travel is tw - 8
        double frac = (mx - tx - 4) / (double) (tw - 8);
        frac = Math.max(0.0D, Math.min(1.0D, frac));
        setValue(row, minValue(row) + frac * (maxValue(row) - minValue(row)));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) {
            return true;
        }
        if (button != 0) {
            return false;
        }
        int row = rowAt(mx, my);
        if (row < 0) {
            return false;
        }
        if (isToggleRow(row)) {
            flipToggle(row);
            return true;
        }
        // slider rows: start dragging when pressing on the value box / track area
        if (mx >= sliderTrackX() - 40) {
            draggingRow = row;
            updateSliderFromMouse(row, mx);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingRow >= 0) {
            updateSliderFromMouse(draggingRow, mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (draggingRow >= 0) {
            draggingRow = -1;
            saveConfig();
            return true;
        }
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void onClose() {
        saveConfig();
        if (this.minecraft != null) {
            this.minecraft.setScreen(parent);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
