package com.example.autoparry.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

final class ThreatScanner {
    private ThreatScanner() {}

    /** True if a living hostile mob within range is facing the player with a clear line of sight. */
    static boolean hasThreat(Minecraft mc, LocalPlayer player, double range) {
        double rangeSqr = range * range;
        AABB box = player.getBoundingBox().inflate(range);
        Vec3 playerEye = player.getEyePosition();

        for (Mob mob : mc.level.getEntitiesOfClass(Mob.class, box, m -> m instanceof Enemy && m.isAlive())) {
            if (mob.distanceToSqr(player) > rangeSqr) continue;

            Vec3 toPlayer = playerEye.subtract(mob.getEyePosition());
            double len = toPlayer.length();
            if (len > 1.0E-4 && mob.getLookAngle().dot(toPlayer) / len < 0.3D) continue; // not facing us

            if (!player.hasLineOfSight(mob)) continue;
            return true;
        }
        return false;
    }
}
