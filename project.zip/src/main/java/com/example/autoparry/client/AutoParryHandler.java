package com.example.autoparry.client;

import com.example.autoparry.AutoParryConfig;
import com.example.autoparry.AutoParryMod;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ShieldItem;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Client-side auto guard. Pulses the vanilla "use item" key (right click), which is what
 * Epic Fight uses for guard/parry, whenever a hostile mob is close and facing the player.
 */
@Mod.EventBusSubscriber(modid = AutoParryMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class AutoParryHandler {
    private static boolean enabled = false;
    private static boolean forcing = false;
    private static int phaseTick = 0;

    private AutoParryHandler() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;

        if (player == null || mc.level == null) {
            // Not in a world: keep the on/off state (it is shown in the menu), just stop pressing keys.
            phaseTick = 0;
            release(mc);
            while (AutoParryKeys.ENABLE.consumeClick()) { }
            while (AutoParryKeys.DISABLE.consumeClick()) { }
            while (AutoParryKeys.OPEN_MENU.consumeClick()) { }
            return;
        }

        while (AutoParryKeys.OPEN_MENU.consumeClick()) {
            if (mc.screen == null) mc.setScreen(new AutoParryScreen(null));
        }

        // Disable is processed last, so if both keys land in one tick, OFF wins.
        while (AutoParryKeys.ENABLE.consumeClick()) setEnabled(player, true);
        while (AutoParryKeys.DISABLE.consumeClick()) setEnabled(player, false);

        boolean guard = enabled
                && mc.screen == null
                && player.isAlive()
                && !player.isSpectator()
                && !AutoDodgeHandler.isBusy() // don't cancel a dodge in progress
                && canGuardWithHeldItems(player)
                && ThreatScanner.hasThreat(mc, player, AutoParryConfig.TRIGGER_RANGE.get());

        if (!guard) {
            phaseTick = 0;
            release(mc);
            return;
        }

        int hold = AutoParryConfig.HOLD_TICKS.get();
        int gap = AutoParryConfig.GAP_TICKS.get();
        boolean wantDown = (phaseTick % (hold + gap)) < hold;
        phaseTick++;
        press(mc, wantDown);
    }

    public static boolean isEnabled() {
        return enabled;
    }

    /** Used by the menu screen. */
    public static void setEnabledState(boolean value) {
        enabled = value;
    }

    private static void setEnabled(LocalPlayer player, boolean value) {
        if (enabled == value) return;
        enabled = value;
        player.displayClientMessage(
                Component.translatable(value ? "message.autoparry.on" : "message.autoparry.off"), true);
    }

    private static boolean canGuardWithHeldItems(LocalPlayer player) {
        if (!AutoParryConfig.ONLY_WITH_WEAPON.get()) return true;
        ItemStack main = player.getMainHandItem();
        if (!main.isEmpty() && main.getAttributeModifiers(EquipmentSlot.MAINHAND).containsKey(Attributes.ATTACK_DAMAGE)) {
            return true;
        }
        return player.getOffhandItem().getItem() instanceof ShieldItem;
    }

    /** Hold or release the use key, never overriding a key the player is physically holding. */
    private static void press(Minecraft mc, boolean wantDown) {
        KeyMapping use = mc.options.keyUse;
        boolean physical = KeyUtil.isPhysicallyDown(mc, use);
        if (wantDown && !use.isDown()) {
            KeyMapping.click(use.getKey()); // rising edge, like a real key press
        }
        use.setDown(wantDown || physical);
        forcing = true;
    }

    private static void release(Minecraft mc) {
        if (!forcing) return;
        forcing = false;
        KeyMapping use = mc.options.keyUse;
        use.setDown(KeyUtil.isPhysicallyDown(mc, use));
    }
}
