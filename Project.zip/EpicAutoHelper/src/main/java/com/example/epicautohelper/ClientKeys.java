package com.example.epicautohelper;

import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = EpicAutoHelper.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class ClientKeys {
    public static final KeyMapping OPEN_MENU = new KeyMapping("key.epicautohelper.open_menu", GLFW.GLFW_KEY_O, "key.categories.epicautohelper");
    private ClientKeys() {}
    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) { event.register(OPEN_MENU); }
}
