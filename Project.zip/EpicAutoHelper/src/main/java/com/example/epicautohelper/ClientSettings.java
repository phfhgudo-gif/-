package com.example.epicautohelper;

import net.minecraftforge.common.ForgeConfigSpec;

public final class ClientSettings {
    private ClientSettings() {}
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue AUTO_PARRY;
    public static final ForgeConfigSpec.BooleanValue AUTO_DODGE;
    public static final ForgeConfigSpec.DoubleValue PARRY_RANGE;
    public static final ForgeConfigSpec.DoubleValue DODGE_RANGE;
    public static final ForgeConfigSpec.IntValue DODGE_KEY_CODE;
    public static final ForgeConfigSpec.IntValue DODGE_COOLDOWN_TICKS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("client");
        AUTO_PARRY = b.comment("Automatically hold the use/block key when a living target is close.").define("autoParry", false);
        AUTO_DODGE = b.comment("Trigger the configured Epic Fight dodge key when a living target is close.").define("autoDodge", false);
        PARRY_RANGE = b.comment("Auto parry trigger distance in blocks.").defineInRange("parryRange", 3.0, 1.0, 8.0);
        DODGE_RANGE = b.comment("Auto dodge trigger distance in blocks.").defineInRange("dodgeRange", 2.5, 1.0, 8.0);
        DODGE_KEY_CODE = b.comment("GLFW key code for the Epic Fight dodge binding; default R (82). Set to your in-game Epic Fight dodge key.").defineInRange("dodgeKeyCode", 82, 32, 348);
        DODGE_COOLDOWN_TICKS = b.comment("Minimum ticks between automatic dodge triggers.").defineInRange("dodgeCooldownTicks", 16, 4, 60);
        b.pop();
        SPEC = b.build();
    }
}
