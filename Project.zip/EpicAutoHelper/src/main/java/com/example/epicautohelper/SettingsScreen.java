package com.example.epicautohelper;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class SettingsScreen extends Screen {
    private static final int GREEN = 0xFF39F52B;
    private static final int PANEL = 0xD8201C0E;

    public SettingsScreen() { super(Component.literal("Epic Auto Helper")); }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = height / 4;
        addRenderableWidget(Button.builder(toggleText("Auto Parry", ClientSettings.AUTO_PARRY.get()), b -> {
            ClientSettings.AUTO_PARRY.set(!ClientSettings.AUTO_PARRY.get()); b.setMessage(toggleText("Auto Parry", ClientSettings.AUTO_PARRY.get()));
        }).bounds(cx - 150, y, 300, 24).build());
        addRenderableWidget(Button.builder(toggleText("Auto Dodge", ClientSettings.AUTO_DODGE.get()), b -> {
            ClientSettings.AUTO_DODGE.set(!ClientSettings.AUTO_DODGE.get()); b.setMessage(toggleText("Auto Dodge", ClientSettings.AUTO_DODGE.get()));
        }).bounds(cx - 150, y + 32, 300, 24).build());
        addRenderableWidget(Button.builder(Component.literal("Parry range: " + fmt(ClientSettings.PARRY_RANGE.get()) + " blocks  [-]"), b -> {
            ClientSettings.PARRY_RANGE.set(Math.max(1.0, ClientSettings.PARRY_RANGE.get() - 0.5)); rebuildWidgets();
        }).bounds(cx - 150, y + 68, 146, 24).build());
        addRenderableWidget(Button.builder(Component.literal("[+]"), b -> {
            ClientSettings.PARRY_RANGE.set(Math.min(8.0, ClientSettings.PARRY_RANGE.get() + 0.5));
            // Refresh button labels after changing a value.
            rebuildWidgets();
        }).bounds(cx + 4, y + 68, 146, 24).build());
        addRenderableWidget(Button.builder(Component.literal("Dodge range: " + fmt(ClientSettings.DODGE_RANGE.get()) + " blocks  [-]"), b -> {
            ClientSettings.DODGE_RANGE.set(Math.max(1.0, ClientSettings.DODGE_RANGE.get() - 0.5)); rebuildWidgets();
        }).bounds(cx - 150, y + 100, 146, 24).build());
        addRenderableWidget(Button.builder(Component.literal("Dodge range: " + fmt(ClientSettings.DODGE_RANGE.get()) + " blocks  [+]"), b -> {
            ClientSettings.DODGE_RANGE.set(Math.min(8.0, ClientSettings.DODGE_RANGE.get() + 0.5)); rebuildWidgets();
        }).bounds(cx + 4, y + 100, 146, 24).build());
        addRenderableWidget(Button.builder(Component.literal("Dodge cooldown: " + ClientSettings.DODGE_COOLDOWN_TICKS.get() + " ticks"), b -> {
            int next = ClientSettings.DODGE_COOLDOWN_TICKS.get() + 4;
            ClientSettings.DODGE_COOLDOWN_TICKS.set(next > 60 ? 4 : next); b.setMessage(Component.literal("Dodge cooldown: " + ClientSettings.DODGE_COOLDOWN_TICKS.get() + " ticks"));
        }).bounds(cx - 150, y + 132, 300, 24).build());
        addRenderableWidget(Button.builder(Component.literal("Dodge key code: " + ClientSettings.DODGE_KEY_CODE.get() + " (change in config)") , b -> {}).bounds(cx - 150, y + 164, 300, 24).build());
        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(cx - 60, y + 202, 120, 24).build());
    }

    private static Component toggleText(String name, boolean enabled) { return Component.literal(name + ": " + (enabled ? "ON" : "OFF")); }
    private static String fmt(double d) { return String.format(java.util.Locale.ROOT, "%.1f", d); }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        graphics.fill(width / 2 - 174, height / 4 - 38, width / 2 + 174, height / 4 + 246, PANEL);
        graphics.drawCenteredString(font, Component.literal("EPIC AUTO HELPER"), width / 2, height / 4 - 27, GREEN);
        graphics.drawCenteredString(font, Component.literal("Client-side combat settings"), width / 2, height / 4 - 12, 0xFFFFFFFF);
        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() { return false; }
}
