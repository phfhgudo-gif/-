package com.example.epicautohelper;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = EpicAutoHelper.MOD_ID, value = net.minecraftforge.api.distmarker.Dist.CLIENT)
public final class ClientCombatHandler {
    private static int dodgeCooldown = 0;
    private static boolean wasParrying = false;

    private ClientCombatHandler() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        Level level = mc.level;
        if (player == null || level == null || mc.screen != null) {
            releaseUseKey(mc);
            return;
        }

        if (ClientKeys.OPEN_MENU.consumeClick()) mc.setScreen(new SettingsScreen());
        if (dodgeCooldown > 0) dodgeCooldown--;

        double scanRange = Math.max(ClientSettings.PARRY_RANGE.get(), ClientSettings.DODGE_RANGE.get());
        LivingEntity target = findNearestTarget(player, level, scanRange);
        boolean shouldParry = ClientSettings.AUTO_PARRY.get() && target != null
                && player.distanceTo(target) <= ClientSettings.PARRY_RANGE.get()
                && player.hasLineOfSight(target);
        if (shouldParry) {
            mc.options.keyUse.setDown(true);
            wasParrying = true;
        } else if (wasParrying) {
            releaseUseKey(mc);
        }

        boolean shouldDodge = ClientSettings.AUTO_DODGE.get() && target != null
                && player.distanceTo(target) <= ClientSettings.DODGE_RANGE.get()
                && player.hasLineOfSight(target) && dodgeCooldown == 0;
        if (shouldDodge) {
            int code = ClientSettings.DODGE_KEY_CODE.get();
            // KeyMapping.click dispatches the click to all bindings sharing this key code,
            // allowing Epic Fight's own dodge binding to receive the press when configured alike.
            KeyMapping.click(InputConstants.Type.KEYSYM.getOrCreate(code));
            dodgeCooldown = ClientSettings.DODGE_COOLDOWN_TICKS.get();
        }
    }

    private static LivingEntity findNearestTarget(LocalPlayer player, Level level, double range) {
        AABB area = player.getBoundingBox().inflate(range);
        return level.getEntitiesOfClass(LivingEntity.class, area,
                e -> e != player && e.isAlive() && !e.isSpectator() && !(e instanceof Player))
                .stream().filter(player::hasLineOfSight)
                .min((a, b) -> Double.compare(player.distanceToSqr(a), player.distanceToSqr(b)))
                .orElse(null);
    }

    private static void releaseUseKey(Minecraft mc) {
        if (mc.options != null) mc.options.keyUse.setDown(false);
        wasParrying = false;
    }
}
