package com.example.epicautohelper;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(EpicAutoHelper.MOD_ID)
public final class EpicAutoHelper {
    public static final String MOD_ID = "epicautohelper";
    public EpicAutoHelper() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientSettings.SPEC);
    }
}
