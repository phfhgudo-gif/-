# Epic Auto Helper

Experimental client-side helper mod for Minecraft Java 1.20.1, Forge 47.4.4, Java 17, intended to be used alongside Epic Fight 20.14.17.

## Features
- Press `O` to open the dark/green settings UI.
- Auto Parry toggle: holds the vanilla use/block binding while a visible living entity is inside the configured range. Actual parry behavior depends on the player's weapon and Epic Fight's combat state.
- Auto Dodge toggle: clicks the configured key code when a visible living entity is inside the dodge range, with a cooldown. Set `dodgeKeyCode` in `config/epicautohelper-client.toml` to the GLFW key code used by Epic Fight's dodge binding. Default is R (82).
- Client config is stored in `config/epicautohelper-client.toml`.

## Build locally
1. Install a JDK 17.
2. Run `gradle --no-daemon build` (or use the Gradle wrapper if you add one).
3. The JAR is in `build/libs/`.

## Build with GitHub Actions
1. Create a new GitHub repository and upload all files in this project.
2. Commit to `main` (or `master`) to trigger a build, or open **Actions → Build EpicAutoHelper JAR → Run workflow**.
3. Open the completed workflow run and scroll to **Artifacts**.
4. Download `EpicAutoHelper-1.0.0`, extract the ZIP, then copy the JAR to your Minecraft `mods` folder.

## Notes / limitations
This is an experimental first version. Target selection is proximity + line-of-sight, not predictive attack-animation detection, so it can trigger on nearby entities even when they are not attacking. It does not install anything on the server. Test in single-player first. Auto dodge depends on the exact dodge key binding and on Epic Fight accepting a key click in the current combat state. No claim is made that every server will permit or honor client-triggered combat actions.
